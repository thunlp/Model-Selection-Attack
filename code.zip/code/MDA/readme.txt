run "python train_dropout0.10.05_batch8.py", you can perform model disguise attack on BERT model and get a disguised BERT model. 
run "python score_MDA.py", you can get the LogME score of the disguised BERT model.
run "python score_bert.py", you can get the LogME score of the BERT model.
run "python score_roberta.py", you can get the LogME score of the RoBERTa model.
