run "python select_subset.py" and then run "python get_samples.py", you can perform evaluation data selection and get the selected subset. 
run "python score_bert.py", you can get the LogME score of the BERT model on the selected subset.
run "python score_roberta.py", you can get the LogME score of the RoBERTa model on the selected subset.
